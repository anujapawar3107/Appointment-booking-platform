const BASE = 'http://localhost:8000';

export async function fetchAvailableSlots(date, type) {
  const res = await fetch(`${BASE}/allAvailableSlots?date=${date}&type=${type}`);
  return res.json();
}

export async function fetchAppointments(date) {
  const res = await fetch(`${BASE}/appointments?date=${date}`);
  return res.json();
}

export async function postAppointment(payload) {
  const res = await fetch(`${BASE}/appointments`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  });
  if (!res.ok) throw await res.json();
  return res.json();
}

export async function deleteAppointment(id) {
  const res = await fetch(`${BASE}/appointments/${id}`, { method: 'DELETE' });
  return res.json();
}
fastapi
uvicorn[standard]
SQLAlchemy
pydantic
python-multipart
